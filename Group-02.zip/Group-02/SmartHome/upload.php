<?php
session_start();
$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = ""; /* Password */
$dbname = "smarthome"; /* Database name */

$con = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_GET['value'])){
    $toRecord = $_GET['value'];
    if($toRecord < 5){
        $selectsql = "SELECT * FROM recordauto1 order by recordTime desc limit 1 ";
        $result = mysqli_query($con, $selectsql);
        $vql = -1;
        while($r = mysqli_fetch_assoc($result)){
             $vql = $r['value']; //Event occuring in a month
        }
        
        if($vql == 1  && $toRecord == 0){
            $currentTime = new DateTime();
            $currentTime->modify('+ 5 hour');
            $insertSQL = "INSERT INTO recordauto1(recordTime, value) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','0')";
            mysqli_query($con, $insertSQL);
        }elseif(($vql == 0 || $vql == -1) && $toRecord == 1){
            $currentTime = new DateTime();
            $currentTime->modify('+ 5 hour');
            $insertSQL = "INSERT INTO recordauto1(recordTime, value) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','1')";
            mysqli_query($con, $insertSQL);
        }
    }elseif($toRecord > 5){
        $selectsql = "SELECT * FROM ldr order by recordTime desc limit 1 ";
        $result = mysqli_query($con, $selectsql);
        $vql = -1;
        while($r = mysqli_fetch_assoc($result)){
             $vql = $r['value']; //Event occuring in a month
        }       
        
        if($vql == 1 && $toRecord == 7){
            $currentTime = new DateTime();
            $currentTime->modify('+ 5 hour');
            $insertSQL = "INSERT INTO ldr(recordTime, value) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','0')";
            mysqli_query($con, $insertSQL);
        }elseif(($vql == 0 || $vql == -1) && $toRecord == 6){
            $currentTime = new DateTime();
            $currentTime->modify('+ 5 hour');
            $insertSQL = "INSERT INTO ldr(recordTime, value) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','1')";
            mysqli_query($con, $insertSQL);
        }
    }


}

?>