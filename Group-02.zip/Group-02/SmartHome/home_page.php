<?php
session_start();
 include("proc.php");
 include("timecountLDR.php");
 include("timecountPIR.php");
 include("timecountAir.php");
$con = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_data);

if(isset($_COOKIE['auto-cookie'])) {

    $_SESSION['auto-session'] = $_COOKIE['auto-cookie'];
}
if(isset($_POST['verifForm'])){
    if (isset($_POST['auto-on'])) {
        $_SESSION['auto-session']='checked';
        setcookie('auto-cookie', 'checked', time() + (86400 * 30), "/");
        $updateSQL = "UPDATE parameters SET value=1 WHERE param='autoMode'";
        mysqli_query($con, $updateSQL);
    } else {
        $_SESSION['auto-session']='';
        setcookie('auto-cookie', '', time() + (86400 * 30), "/");
        $updateSQL = "UPDATE parameters SET value=0 WHERE param='autoMode'";
        mysqli_query($con, $updateSQL);
    }

    if(isset($_POST['onOff'])) {

        $_SESSION['status'] = 'checked';
    $selectsql = "SELECT * FROM recordlight order by recordTime desc limit 1 ";
    $result = mysqli_query($con, $selectsql);
    while($r = mysqli_fetch_assoc($result)){
            $vql = $r['type']; //Event occuring in a month
    }
    if($vql == 0){
        $currentTime = new DateTime();
        $currentTime->modify('+ 5 hour');
        //echo $currentTime->format('Y-m-d H:i:s');
        $insertSQL = "INSERT INTO recordLight(recordTime, type) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','1')";
        mysqli_query($con, $insertSQL);
    }

    }
    else {
        $_SESSION['status'] = '';
        $selectsql = "SELECT * FROM recordlight order by recordTime desc limit 1 ";
        $result = mysqli_query($con, $selectsql);
        while($r = mysqli_fetch_assoc($result)){
            $vql = $r['type']; //Event occuring in a month
        }
        if($vql == 1){
            $currentTime = new DateTime();
            $currentTime->modify('+ 5 hour');
            //echo $currentTime->format('Y-m-d H:i:s');
            $insertSQL = "INSERT INTO recordLight(recordTime, type) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','0')";
            mysqli_query($con, $insertSQL);
        }
    }


    if(isset($_POST['onOffAir'])) {
        $_SESSION['status-air'] = 'checked';
    $selectsql = "SELECT * FROM recordAir order by recordTime desc limit 1 ";
    $result = mysqli_query($con, $selectsql);
    while($r = mysqli_fetch_assoc($result)){
            $vql = $r['type']; //Event occuring in a month
    }
    if($vql == 0){
        $currentTime = new DateTime();
        $currentTime->modify('+ 5 hour');
        //echo $currentTime->format('Y-m-d H:i:s');
        $insertSQL = "INSERT INTO recordAir(recordTime, type) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','1')";
        mysqli_query($con, $insertSQL);
    }

    }
    else {
        $_SESSION['status-air'] = '';
        $selectsql = "SELECT * FROM recordAir order by recordTime desc limit 1 ";
        $result = mysqli_query($con, $selectsql);
        while($r = mysqli_fetch_assoc($result)){
            $vql = $r['type']; //Event occuring in a month
        }
        if($vql == 1){
            $currentTime = new DateTime();
            $currentTime->modify('+ 5 hour');
            //echo $currentTime->format('Y-m-d H:i:s');
            $insertSQL = "INSERT INTO recordAir(recordTime, type) VALUE ('".$currentTime->format('Y-m-d H:i:s')."','0')";
            mysqli_query($con, $insertSQL);
        }

    }
}  
$con->close();
?>
<!doctype html>
    <html lang="en">
    <head>
        <title>Home Page</title>
        <link rel="stylesheet" type="text/css" href="myStyle.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"
              integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <script src="myScript.js"></script>
        <style>
            #txt{
                text-align: center ;
                color: black;
                font-weight: bold ;
                font-size: 50px ;
                padding: 15px 0;
            }
            .card{
                margin: 0 53px 0 0 ;
                border: none;
                background-color: transparent;
            }
            .box-shadow{
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                text-align: center;
            }
            .table-data{
                width: 100%;
            }
            table, th, td{
                border: 1px solid #878787;
                background: #e9e9e9;
                border-radius: 5px;
                text-align: center;
                padding: 5px;
                margin: 15px 0 0 0;
            }
            .list ul{
                padding: 0;
                margin-top: 10px;
                list-style: none;
            }
            .list ul li{
                float: left;
                margin-right: 10px;
            }
            .list ul li a{
                color: #000000;
                text-decoration: none;
                background: #e2e2e2;
                /*border: 1px solid#878787;*/
            }
            .Manual{
                padding: 10px 48px
            }
            .Air{
                padding: 10px 28px;
            }
            .PIR{
                padding: 10px 62px
            }
            .LDR{
                padding: 10px 59px
            }
            .Manual:hover{
                padding: 10px 48px;
                background: #343a40!important;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.3), 0 6px 20px 0 rgba(0, 0, 0, 0.10);
                color: white;
            }
            .Air:hover{
                padding: 10px 28px;
                background: #343a40!important;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.3), 0 6px 20px 0 rgba(0, 0, 0, 0.10);
                color: white;
            }
            .PIR:hover{
                padding: 10px 62px;
                background: #343a40!important;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.3), 0 6px 20px 0 rgba(0, 0, 0, 0.10);
                color: white;
            }
            .LDR:hover{
                padding: 10px 59px;
                background: #343a40!important;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.3), 0 6px 20px 0 rgba(0, 0, 0, 0.10);
                color: white;
            }
            .margin{
                float: right;
                /*padding-right: 100px;*/
            }
            .list-group-item.active {
                z-index: 2;
                color: #fff;
                background: #343a40!important;
                border-color: #007bff;
            }
            .list-group{
                padding-top: 35px;
            }
        </style>
    </head>
    <body background="Resources/Images/124226-house-background-1920x1200-picture.jpg" onload="startTime()">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="home_page.php">SmartHome</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <div id="txt"></div>
    <div class="container Bo-dy">
        <div class="row">
            <div class="col-md-12">
                <form method="post">
                    <input type="text" name="verifForm" value='ok' hidden>
                    <div class="card" id="onOffCard">
                        <img class="card-img-top" src="./Resources/Images/light_off.png" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-text">Turned off</h5>

                            <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
                            <!-- Rounded switch -->
                            <label class="switch">
                                <input type="checkbox" name="onOff" class="toggle" onchange="this.form.submit();"
                                       id="onOffToggle" <?php
                                if (isset($_SESSION['status'])) echo $_SESSION['status'];
                                ?>>
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                    <div class="card" id="settingCard">
                        <img class="card-img-top" src="Resources/Images/loading.png" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-text">Auto mode</h5>

                            <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
                            <!-- Rounded switch -->
                            <label class="switch">
                                <input type="checkbox" name="auto-on" class="toggle"

                                       id="settingToggle" onclick="this.form.submit()" <?php
                                if (isset($_SESSION['auto-session'])) {
                                    echo $_SESSION['auto-session'];
                                } ?>>
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>
                    <div class="card" id="onOffAir">
                        <img class="card-img-top" src="./Resources/Images/airOff.png" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-text">Turned off</h5>

                            <!--<a href="#" class="btn btn-primary">Go somewhere</a>-->
                            <!-- Rounded switch -->
                            <label class="switch">
                                <input type="checkbox" name="onOffAir" class="toggle" onchange="this.form.submit();"
                                       id="onOffToggleAir" <?php
                                if (isset($_SESSION['status-air'])) echo $_SESSION['status-air'];
                                ?>>
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>

                    <div class="card" id="electricUsageCard">
                        <div class="list-group">
                            <a href="home_page.php?value=a" class="list-group-item list-group-item-action flex-column align-items-start active">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1">Daily Usage</h5>

                                </div>

                                <small>Donec id elit non mi porta.</small>
                            </a>
                            <a href="home_page.php" class="list-group-item list-group-item-action flex-column align-items-start">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-1">Monthly Usage</h5>

                                </div>

                                <small class="text-muted">Donec id elit non mi porta.</small>
                            </a>
                        </div>
                    </div>

                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="list">
                    <ul>
                        <li><div class="box-shadow"><a class="Manual" href="home_page.php?value=a"><b>Manual</b></a></div></li>
                        <li><div class="box-shadow"><a class="LDR" href="home_page.php?value=b"><b>LDR</b></a></div></li>
                        <li><div class="box-shadow"><a class="PIR" href="home_page.php?value=c"><b>PIR</b></a></div></li>
                        <li><div class="box-shadow"><a class="Air" href="home_page.php?value=d"><b>AirCondition</b></a></div></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box-shadow">
                    <table class="table-data">
                    <thead>
                        <tr>
                            <th width="50%">Date</th>
                            <th width="50%">Wattage Hour</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        if (isset($_GET['value'])){
                            $para = $_GET['value'];
                            if ($para == 'a'){
                                $compteur = 0;
                                foreach($dailyconsumption as $temp){
                                    echo "<tr>";
                                    echo "<td>".$listDays[$compteur++]."</td>";
                                    echo "<td>".$temp."<span class='margin'>Wh</span></td>";
                                    echo "</tr>";
                                }
                            }
                            if ($para == 'b'){
                                $compteurLDR= 0;
                                foreach($dailyconsumptionLDR as $tempLDR){
                                    echo "<tr>";
                                    echo "<td>".$listDaysLDR[$compteurLDR++]."</td>";
                                    echo "<td>".$tempLDR."<span class='margin'>Wh</span></td>";
                                    echo "</tr>";
                                }
                            }
                            if ($para == 'c'){
                                $compteurPIR = 0;
                                foreach($dailyconsumptionPIR as $tempPIR){
                                    echo "<tr>";
                                    echo "<td>".$listDaysPIR[$compteurPIR++]."</td>";
                                    echo "<td>".$tempPIR."<span class='margin'>Wh</span></td>";
                                    echo "</tr>";
                                }
                            }
                            if ($para == 'd'){
                                $compteur = 0;
                                foreach($dailyconsumptionAir as $tempAir){
                                    echo "<tr>";
                                    echo "<td>".$listDaysAir[$compteur++]."</td>";
                                    echo "<td>".$tempAir."<span class='margin'>Wh</span></td>";
                                    echo "</tr>";
                                }
                            }
                        }
                        
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    </body>
    <script>updateContent('onOffCard','<?php if(isset($_SESSION['status'])) echo $_SESSION['status'] ?>');updateContent('settingCard','<?php if(isset($_SESSION['auto-session'])) echo $_SESSION['auto-session'] ?>');updateContent('onOffAir','<?php if(isset($_SESSION['status-air'])) echo $_SESSION['status-air'] ?>');</script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
            integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"
            integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
            crossorigin="anonymous"></script>
    <script>
        function startTime() {
            var today = new Date();
            var h = today.getHours();
            var m = today.getMinutes();
            var s = today.getSeconds();
            m = checkTime(m);
            s = checkTime(s);
            document.getElementById('txt').innerHTML =
                h + ":" + m + ":" + s;
            var t = setTimeout(startTime, 500);
        }
        function checkTime(i) {
            if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
            return i;
        }
    </script>
</html>