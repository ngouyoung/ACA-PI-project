<?php
define("DB_HOST",'localhost');
define("DB_USER",'root');
define("DB_PASSWORD",'');
define("DB_data",'smarthome');

$con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_data);


$voltage = 3;
$current = 0.02;
$wattage = ($current * $voltage)*4;

$selectsql = "SELECT * FROM recordlight";
$record = array();
$result = mysqli_query($con, $selectsql);
while($r = mysqli_fetch_assoc($result)){
    $record[] = $r; //Event occuring in a month
}

$con->close();
$dailyconsumption = array();
$dailyconsumption[0] = 0;
$listDays = array();
$compteurDay=0;

foreach($record as $temp){
    if(count($listDays) == 0)
        $listDays[] = (new DateTime($temp['recordTime']))->format('Y-m-d');
    //Event of opening the tap
    if($temp['type'] == 1){
        $dateTemp = new DateTime($temp['recordTime']);
        if(isset($dateClose)){
            if($dateClose->format('Y-m-d') != $dateTemp->format('Y-m-d')){
                $dailyconsumption[++$compteurDay] = 0;
                $listDays[] = $dateTemp->format('Y-m-d');
            }
        }
    }
    //Event of closing the tap
    else{
        $dateClose = new DateTime($temp['recordTime']);
        if(isset($dateTemp)){
            if($dateClose->format('Y-m-d') != $dateTemp->format('Y-m-d')){
                $listDays[] = $dateClose->format('Y-m-d');
                //Total time between the two events
                $diffTotal = abs($dateTemp->getTimestamp() - $dateClose->getTimestamp());
                $startDay = new DateTime($dateClose->format('Y-m-d'));
                $diffStart = abs($startDay->getTimestamp() - $dateClose->getTimestamp());
                //Add conso to day before
                $dailyconsumption[$compteurDay] += round((($diffTotal - $diffStart) * $wattage),2);
                //Add the rest to the day after
                $dailyconsumption[++$compteurDay] = round(($diffStart * $wattage),2);
            }else{
                $diff = abs($dateTemp->getTimestamp() - $dateClose->getTimestamp());
                $dailyconsumption[$compteurDay] += round(($diff * $wattage),2);
            }
        }else{//If the record start by a closing event
            $startDay = new DateTime($dateClose->format('Y-m-d'));
            $diffStart = abs($startDay->getTimestamp() - $dateClose->getTimestamp());
            $dailyconsumption[$compteurDay] += round(($diffStart * $wattage),2);
        }
    }
}

?>