<?php
define("DB_HOST",'localhost');
define("DB_USER",'root');
define("DB_PASSWORD",'');
define("DB_data",'smarthome');

$con = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_data);

$selectsql = "SELECT * FROM recordlight order by recordTime desc limit 1 ";
$result = mysqli_query($con, $selectsql);
while($r = mysqli_fetch_assoc($result)){
     $vql = $r['type']; //Event occuring in a month
}

$selectsql = "SELECT * FROM recordAir order by recordTime desc limit 1 ";
$result = mysqli_query($con, $selectsql);
while($r = mysqli_fetch_assoc($result)){
     $vqlair = $r['type']; //Event occuring in a month
}

$selectsql = "SELECT * FROM parameters where param='autoMode'";
$result = mysqli_query($con, $selectsql);
while($r = mysqli_fetch_assoc($result)){
    if($r['value'] == 1){
        $v2 = 1;
    }else{
        $v2 = 0;
    }
}
echo $vql.$v2.$vqlair;
$con->close();
?>