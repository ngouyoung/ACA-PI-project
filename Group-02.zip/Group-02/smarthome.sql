CREATE DATABASE  IF NOT EXISTS `smarthome`;
-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2018 at 07:25 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smarthome`
--

-- --------------------------------------------------------

--
-- Table structure for table `ldr`
--

CREATE TABLE `ldr` (
  `id` int(11) NOT NULL,
  `recordTime` datetime NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ldr`
--

INSERT INTO `ldr` (`id`, `recordTime`, `value`) VALUES
(1, '2018-07-07 01:00:00', 1),
(2, '2018-07-07 13:01:20', 0),
(3, '2018-07-08 00:00:00', 1),
(4, '2018-07-08 01:00:00', 0),
(5, '2018-07-09 13:30:07', 1),
(6, '2018-07-09 14:20:45', 0),
(7, '2018-07-10 14:18:22', 1),
(8, '2018-07-10 15:41:25', 0),
(9, '2018-07-11 00:50:45', 1),
(10, '2018-07-11 01:20:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `parameters`
--

CREATE TABLE `parameters` (
  `id` int(11) NOT NULL,
  `param` varchar(150) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parameters`
--

INSERT INTO `parameters` (`id`, `param`, `value`) VALUES
(1, 'autoMode', 1);

-- --------------------------------------------------------

--
-- Table structure for table `recordair`
--

CREATE TABLE `recordair` (
  `id` int(11) NOT NULL,
  `recordTime` datetime NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recordair`
--

INSERT INTO `recordair` (`id`, `recordTime`, `type`) VALUES
(1, '2018-07-07 21:30:59', 1),
(2, '2018-07-07 07:01:20', 0),
(3, '2018-07-08 20:00:02', 1),
(4, '2018-07-08 09:30:04', 0),
(5, '2018-07-09 13:30:07', 1),
(6, '2018-07-09 18:20:45', 0),
(7, '2018-07-10 14:18:22', 1),
(8, '2018-07-10 23:41:25', 0),
(9, '2018-07-11 00:50:45', 1),
(10, '2018-07-11 07:30:00', 0),
(11, '2018-07-11 12:20:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `recordauto1`
--

CREATE TABLE `recordauto1` (
  `id` int(11) NOT NULL,
  `recordTime` datetime NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recordauto1`
--

INSERT INTO `recordauto1` (`id`, `recordTime`, `value`) VALUES
(1, '2018-07-07 19:23:15', 1),
(2, '2018-07-07 19:23:40', 0),
(3, '2018-07-07 20:00:40', 1),
(4, '2018-07-07 20:01:00', 0),
(5, '2018-07-08 17:01:20', 1),
(6, '2018-07-08 17:02:00', 0),
(7, '2018-07-08 20:30:09', 1),
(8, '2018-07-08 20:30:50', 0),
(9, '2018-07-09 18:05:03', 1),
(10, '2018-07-09 18:05:33', 0),
(11, '2018-07-09 20:11:25', 1),
(12, '2018-07-09 20:11:49', 0),
(13, '2018-07-10 00:01:00', 1),
(14, '2018-07-10 00:01:30', 0),
(15, '2018-07-10 03:03:05', 1),
(16, '2018-07-10 03:03:45', 0),
(17, '2018-07-11 02:20:23', 1),
(18, '2018-07-11 02:20:53', 0),
(19, '2018-07-11 02:23:53', 1),
(20, '2018-07-11 02:24:13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `recordlight`
--

CREATE TABLE `recordlight` (
  `id` int(11) NOT NULL,
  `recordTime` datetime NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recordlight`
--

INSERT INTO `recordlight` (`id`, `recordTime`, `type`) VALUES
(1, '2018-07-07 05:30:00', 1),
(2, '2018-07-07 06:01:20', 0),
(3, '2018-07-08 20:00:02', 1),
(4, '2018-07-08 21:00:59', 0),
(5, '2018-07-09 13:30:07', 1),
(6, '2018-07-09 14:20:45', 0),
(7, '2018-07-10 20:45:37', 1),
(8, '2018-07-10 23:41:25', 0),
(9, '2018-07-11 00:50:45', 1),
(10, '2018-07-11 01:17:45', 0),
(11, '2018-07-11 01:27:50', 1),
(12, '2018-07-11 01:28:45', 0),
(13, '2018-07-11 01:30:00', 1),
(14, '2018-07-11 01:31:00', 0),
(15, '2018-07-11 01:31:30', 1),
(16, '2018-07-11 01:32:00', 0),
(17, '2018-07-11 01:33:13', 1),
(18, '2018-07-11 01:33:21', 0),
(19, '2018-07-11 01:33:31', 1),
(20, '2018-07-11 01:33:50', 0),
(21, '2018-07-11 12:20:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, '1234', '202cb962ac59075b964b07152d234b70'),
(2, 'ratanak', '202cb962ac59075b964b07152d234b70'),
(3, 'Chung', '202cb962ac59075b964b07152d234b70'),
(4, 'uong', '202cb962ac59075b964b07152d234b70'),
(5, 'sophorn', '202cb962ac59075b964b07152d234b70'),
(6, 'hout', '202cb962ac59075b964b07152d234b70'),
(7, 'tola', '202cb962ac59075b964b07152d234b70'),
(8, 'sokmeng', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ldr`
--
ALTER TABLE `ldr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parameters`
--
ALTER TABLE `parameters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recordair`
--
ALTER TABLE `recordair`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recordauto1`
--
ALTER TABLE `recordauto1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recordlight`
--
ALTER TABLE `recordlight`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ldr`
--
ALTER TABLE `ldr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `parameters`
--
ALTER TABLE `parameters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `recordair`
--
ALTER TABLE `recordair`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `recordauto1`
--
ALTER TABLE `recordauto1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `recordlight`
--
ALTER TABLE `recordlight`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
