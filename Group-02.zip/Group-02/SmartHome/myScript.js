/*Update content according to toggle */
function updateContent(card, status) {
    var image = document.getElementById(card).children[0];
    var toggleText = document.getElementById(card).children[1].children[0];
    //var toggle = document.getElementById(toggleID);
    if (card === "onOffCard") {

        if (status==='checked') {
            toggleText.innerText = "Turned on";
            image.src = "Resources/Images/light_on.png";
        }
        else {
            toggleText.innerText = "Turned off";
            image.src = "Resources/Images/light_off.png";
        }
    }
    else if (card === "settingCard") {
        if (status === 'checked') {
            //toggleText.innerText = "Auto mode on";
            image.src = "Resources/Images/loading.gif";

        }
        else {
            //toggleText.innerText = "Auto mode off";
            image.src = "Resources/Images/loading.png";
        }
    }
    else if (card === "onOffAir"){
        if (status==='checked') {
            toggleText.innerText = "Turned on";
            image.src = "Resources/Images/air.gif";
        }
        else {
            toggleText.innerText = "Turned off";
            image.src = "Resources/Images/airOff.png";
        }
    }



}
function updatePart() {
    $("#settingCard").load("index.php #settingCard");
}

