<?php

$con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_data);


$voltageAir = 3;
$currentAir = 1;
$wattageAir = $currentAir * $voltageAir;

$selectsqlAir = "SELECT * FROM recordAir";
$recordAir = array();
$resultAir = mysqli_query($con, $selectsqlAir);
while($r = mysqli_fetch_assoc($resultAir)){
    $recordAir[] = $r; //Event occuring in a month
}
$con->close();
$dailyconsumptionAir = array();
$dailyconsumptionAir[0] = 0;
$listDaysAir = array();
$compteurDayAir=0;
foreach($recordAir as $tempAir){
    if(count($listDaysAir) == 0)
        $listDaysAir[] = (new DateTime($tempAir['recordTime']))->format('Y-m-d');
    //Event of opening the tap
    if($tempAir['type'] == 1){
        $dateTempAir = new DateTime($tempAir['recordTime']);
        if(isset($dateCloseAir)){
            if($dateCloseAir->format('Y-m-d') != $dateTempAir->format('Y-m-d')){
                $dailyconsumptionAir[++$compteurDayAir] = 0;
                $listDaysAir[] = $dateTempAir->format('Y-m-d');
            }
        }
    }
    //Event of closing the tap
    else{
        $dateCloseAir = new DateTime($tempAir['recordTime']);
        if(isset($dateTempAir)){
            if($dateCloseAir->format('Y-m-d') != $dateTempAir->format('Y-m-d')){
                $listDaysAir[] = $dateCloseAir->format('Y-m-d');
                //Total time between the two events
                $diffTotalAir = abs($dateTempAir->getTimestamp() - $dateCloseAir->getTimestamp());
                $startDayAir = new DateTime($dateCloseAir->format('Y-m-d'));
                $diffStartAir = abs($startDay->getTimestamp() - $dateCloseAir->getTimestamp());
                //Add conso to day before
                $dailyconsumptionAir[$compteurDayAir] += round((($diffTotalAir - $diffStartAir) * $wattageAir),2);
                //Add the rest to the day after
                $dailyconsumptionAir[++$compteurDayAir] = round(($diffStartAir * $wattageAir),2);
            }else{
                $diffAir = abs($dateTempAir->getTimestamp() - $dateCloseAir->getTimestamp());
                $dailyconsumptionAir[$compteurDayAir] += round(($diffAir * $wattageAir),2);
            }
        }else{//If the recordAir start by a closing event
            $startDayAir = new DateTime($dateCloseAir->format('Y-m-d'));
            $diffStartAir = abs($startDay->getTimestamp() - $dateCloseAir->getTimestamp());
            $dailyconsumptionAir[$compteurDayAir] += round(($diffStartAir * $wattageAir),2);
        }
    }
}

?>