<?php

$con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_data);


$voltagePIR = 3;
$currentPIR = 0.02;
$wattagePIR = $currentPIR * $voltagePIR;
$selectsqlPIR = "SELECT * FROM recordauto1";
$recordPIR = array();
$resultPIR = mysqli_query($con, $selectsqlPIR);
while($r = mysqli_fetch_assoc($resultPIR)){
    $recordPIR[] = $r; //Event occuring in a month
}
$con->close();
$dailyconsumptionPIR = array();
$dailyconsumptionPIR[0] = 0;
$listDaysPIR = array();
$compteurDayPIR=0;
foreach($recordPIR as $tempPIR){
    if(count($listDaysPIR) == 0)
        $listDaysPIR[] = (new DateTime($tempPIR['recordTime']))->format('Y-m-d');
    //Event of opening the tap
    if($tempPIR['value'] == 1){
        $dateTempPIR = new DateTime($tempPIR['recordTime']);
        if(isset($dateClosePIR)){
            if($dateClosePIR->format('Y-m-d') != $dateTempPIR->format('Y-m-d')){
                $dailyconsumptionPIR[++$compteurDayPIR] = 0;
                $listDaysPIR[] = $dateTempPIR->format('Y-m-d');
            }
        }
    }
    //Event of closing the tap
    else{
        $dateClosePIR = new DateTime($tempPIR['recordTime']);
        if(isset($dateTempPIR)){
            if($dateClosePIR->format('Y-m-d') != $dateTempPIR->format('Y-m-d')){
                $listDaysPIR[] = $dateClosePIR->format('Y-m-d');
                //Total time between the two events
                $diffTotalPIR = abs($dateTempPIR->getTimestamp() - $dateClosePIR->getTimestamp());
                $startDayPIR = new DateTime($dateClosePIR->format('Y-m-d'));
                $diffStartPIR = abs($startDayPIR->getTimestamp() - $dateClosePIR->getTimestamp());
                //Add conso to day before
                $dailyconsumptionPIR[$compteurDayPIR] += round((($diffTotalPIR - $diffStartPIR) * $wattagePIR),2);
                //Add the rest to the day after
                $dailyconsumptionPIR[++$compteurDayPIR] = round(($diffStartPIR * $wattagePIR),2);
            }else{
                $diffPIR = abs($dateTempPIR->getTimestamp() - $dateClosePIR->getTimestamp());
                $dailyconsumptionPIR[$compteurDayPIR] += round(($diffPIR * $wattagePIR),2);
            }
        }else{//If the record start by a closing event
            $startDayPIR = new DateTime($dateClosePIR->format('Y-m-d'));
            $diffStartPIR = abs($startDayPIR->getTimestamp() - $dateClosePIR->getTimestamp());
            $dailyconsumptionPIR[$compteurDayPIR] += round(($diffStartPIR * $wattagePIR),2);
        }
    }
}

?>