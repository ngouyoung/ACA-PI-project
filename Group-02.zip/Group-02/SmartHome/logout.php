<?php
    unset($_COOKIE['rememberme']);
    setcookie("rememberme",null, -1,'/');
    session_start();
    session_destroy();
    header("Location: login.php");
?>