<?php
if(isset($_COOKIE['auto-cookie'])) {
    echo $_COOKIE['auto-cookie'];
}
?>