<?php

$con = mysqli_connect("localhost", "root", "", "smarthome");

$voltageLDR = 3;
$currentLDR = 0.02;
$wattageLDR = $currentLDR * $voltageLDR;
$sqlLDR = "SELECT * FROM ldr";
$rLDR = array();
$rsLDR=mysqli_query($con,$sqlLDR);
while($rowLDR = mysqli_fetch_assoc($rsLDR)){
    $rLDR[] = $rowLDR;
}

$con->close();
$dailyconsumptionLDR = array();
$dailyconsumptionLDR[0]=0;
$listDaysLDR = array();
$compteurDayLDR = 0;

foreach($rLDR as $tempLDR){
    if  (count($listDaysLDR) == 0){
        $listDaysLDR[] = (new DateTime($tempLDR['recordTime']))->format('Y-m-d');
    }
    if($tempLDR['value'] == 1){
        $dateTempLDR = new DateTime($tempLDR['recordTime']);
        if(isset($dateCloseLDR)){
            if($dateCloseLDR->format('Y-m-d') != $dateTempLDR->format('Y-m-d')){
                $dailyconsumptionLDR[++$compteurDayLDR] = 0;
                $listDaysLDR[] = $dateTempLDR->format('Y-m-d');
            }
        }
    }
    else{
        $dateCloseLDR = new DateTime($tempLDR['recordTime']);
        if(isset($dateTempLDR)){
            if($dateCloseLDR->format('Y-m-d') != $dateTempLDR->format('Y-m-d')){
                $listDaysLDR[] = $dateCloseLDR->format('Y-m-d');
                //Total time between the two events
                $diffTotalLDR = abs($dateTempLDR->getTimestamp() - $dateCloseLDR->getTimestamp());
                $startDayLDR = new DateTime($dateCloseLDR->format('Y-m-d'));
                $diffStartLDR = abs($startDayLDR->getTimestamp() - $dateCloseLDR->getTimestamp());
                //Add conso to day before
                $dailyconsumptionLDR[$compteurDayLDR] += round((($diffTotalLDR - $diffStartLDR) * $wattageLDR),2);
                //Add the rest to the day after
                $dailyconsumptionLDR[++$compteurDayLDR] = round(($diffStartLDR * $wattageLDR),2);
            }else{
                $diffLDR = abs($dateTempLDR->getTimestamp() - $dateCloseLDR->getTimestamp());
                $dailyconsumptionLDR[$compteurDayLDR] += round(($diffLDR * $wattageLDR),2);
            }
        }else{//If the record start by a closing event
            $startDayLDR = new DateTime($dateClose->format('Y-m-d'));
            $diffStartLDR = abs($startDayLDR->getTimestamp() - $dateCloseLDR->getTimestamp());
            $dailyconsumptionLDR[$compteurDayLDR] += round(($diffStartLDR * $wattageLDR),2);
        }
    }
}

//


?>
