import serial, time, urllib2

arduino = serial.Serial('COM3', 9600, timeout=.1)
#time.sleep(1)
statu=0
while True:
    time.sleep(0.1)
    response = urllib2.urlopen("http://localhost:8080/smarthome/onOff.php")
    data = response.readline()
    if data == "000":
        if statu != 0:
            statu = 0
            arduino.write("0")
    elif data == "001":
        if statu != 1:
            statu = 1
            arduino.write("1")    
    elif data == "010":
        if statu != 2:
            statu = 2
            arduino.write("2")    
    elif data == "011":
        if statu != 3:
            statu = 3
            arduino.write("3")
    elif data == "100":
        if statu != 4:
            statu = 4
            arduino.write("4")       
    elif data == "101":
        if statu != 5:
            statu = 5
            arduino.write("5") 
    elif data == "110":
        if statu != 6:
            statu = 6
            arduino.write("6") 
    elif data == "111":
        if statu != 7:
            statu = 7
            arduino.write("7")    
    data = arduino.readline()
    if data:
        print data
        response = urllib2.urlopen("http://localhost:8080/smarthome/upload.php?value="+str(data))